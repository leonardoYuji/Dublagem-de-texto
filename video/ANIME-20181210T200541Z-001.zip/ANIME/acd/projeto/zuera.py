print(4*4)
