import cv2
import numpy as np

imagem = cv2.imread('lena.png')
largura = imagem.shape[0]
altura = imagem.shape[1]
for i in range(largura):
    for o in range(altura):
        (b, g, r) = imagem[i, o]
        print (b,g,r)
        blue = b + 0
        green = g + 0
        red = r + 0
        media = (blue + green + red)/3
        print media
        imagem[i,o] = (media,media,media)
cv2.imshow('dpoisajd',imagem)
cv2.waitKey(0)
