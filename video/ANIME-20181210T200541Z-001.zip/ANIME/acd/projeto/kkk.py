
gasto = raw_input('qual foi a quantia de gasto deste mes?')
if gasto>100:
	print 'se fodeu. Voce gastou %.2f' % gasto


	
